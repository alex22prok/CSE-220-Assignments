/* DO NOT ADD CODE TO THIS FILE. IT WILL BE REPLACED DURING GRADING. */
#include <assert.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int encrypt(const char *plaintext, char *ciphertext, int key);
int decrypt(const char *ciphertext, char *plaintext, int key);
